case class Database(tables: List[Table]) {
  override def toString: String = {
    tables.foldLeft("")(_ + _)
  }

  def create(tableName: String): Database = {
    if (tables.foldLeft(false)((acc, table) => acc || table.tableName == tableName))
      this
    else Database(tables :+ Table(tableName, List.empty[Map[String, String]]))
  }

  def drop(tableName: String): Database = {
    val db = tables.foldLeft(List.empty[Table])((acc, table) =>
      if table.tableName == tableName then acc else acc :+ table)
    Database(db)
  }

  def selectTables(tableNames: List[String]): Option[Database] = {
    val names = tables.map(_.tableName)
    if (tableNames.forall(names.contains(_))) {
      Some(Database(tables.filter(table => tableNames.contains(table.tableName))))
    } else {
      None
    }
  }

  def join(table1: String, c1: String, table2: String, c2: String): Option[Table] = {
    val tableList = selectTables(List(table1, table2))
    if (tableList.isEmpty) return None
    val tab1 = tableList.get(0)
    val tab2 = tableList.get(1)
    if (tab1.tableData.isEmpty) return Some(tab2)
    if (tab2.tableData.isEmpty) return Some(tab1)

    // Functie care adauga o celula noua pe un rand, daca celula respectiva exista
    // deja, incearca sa le combine
    def addCell(acc: Row, cell: (String, String), merger: Row): Row = {
      if (cell._2 == "") {
        acc + (cell._1 -> merger.getOrElse(cell._1, ""))
      } else if (merger.contains(cell._1) && merger(cell._1) != cell._2) {
        acc + (cell._1 -> (cell._2 + ";" + merger(cell._1)))
      } else {
        acc + cell
      }
    }

    def joinRows(row1: Row, row2: Row): Row = {
      row1.foldLeft(Map.empty[String, String])(addCell(_, _,
        row2.filter((key, value) => key != c2)))
    }

    // Functie care combina 2 randuri daca elementele din coloanele de identificare
    // sunt egale
    def searchMatch(row: Row, table: List[Row]): Row = {
      table.foldLeft(row)((acc, entry) =>
        if entry(c2) == row(c1) then joinRows(row, entry) else acc)
    }

    val new_columns = tab2.header.filter(_ != c2).filter(!tab1.header.contains(_))
      .map(_ -> "").toMap

    val new_data = tab1.tableData.map(_ ++ new_columns)
      .map(searchMatch(_, tab2.tableData))

    // Functia care trateaza cazurile speciale, in care randurile nu se regasesc
    // in ambele tabele
    def make(acc: List[Row], rem: List[Row],
             tab1: List[Row], tab2: List[Row]): List[Row] = {
      if (tab1.isEmpty) {
        acc ++ rem ++ tab2
      } else if (tab2.foldLeft(false)((acc, entry) => acc ||
        Field(c1, _ == tab1.head(c1)).eval(entry).get)) {
        make(acc :+ tab1.head, rem, tab1.tail,
          tab2.filter(entry => !Field(c1, _ == tab1.head(c1)).eval(entry).get))
      } else {
        make(acc, rem :+ tab1.head, tab1.tail, tab2)
      }
    }

    Some(Table("", make(List.empty[Row], List.empty[Row], new_data,
      tab2.tableData.map(row => {
        val cell = row(c2)
        row - c2 + (c1 -> cell)
      }))))
  }

  // Implement indexing here
  def apply(idx: Int): Table = {
    def aux_apply(idx: Int, tables: List[Table]): Table = {
      if (idx <= 0) tables.head
      else aux_apply(idx - 1, tables.tail)
    }
    aux_apply(idx, tables)
  }
}
