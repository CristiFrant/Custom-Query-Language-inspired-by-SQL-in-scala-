import scala.language.implicitConversions

trait PP_SQL_DB{
  def eval: Option[Database]
}

case class CreateTable(database: Database, tableName: String) extends PP_SQL_DB{
  def eval: Option[Database] = Some(database.create(tableName))
}

case class DropTable(database: Database, tableName: String) extends PP_SQL_DB{
  def eval: Option[Database] = Some(database.drop(tableName))
}

implicit def PP_SQL_DB_Create_Drop(t: (Option[Database], String, String)): Option[PP_SQL_DB] = {
  if (t._1.isEmpty) return None
  t._2 match
    case "CREATE" => Some(CreateTable(t._1.get, t._3))
    case "DROP" => Some(DropTable(t._1.get, t._3))
    case _ => None
}


case class SelectTables(database: Database, tableNames: List[String]) extends PP_SQL_DB{
  def eval: Option[Database] = database.selectTables(tableNames)
}

implicit def PP_SQL_DB_Select(t: (Option[Database], String, List[String])): Option[PP_SQL_DB] = {
  if (t._1.isEmpty || t._2 != "SELECT") None
  else Some(SelectTables(t._1.get, t._3))
}

case class JoinTables(database: Database, table1: String, column1: String, table2: String, column2: String) extends PP_SQL_DB{
  def eval: Option[Database] = database.join(table1, column1, table2, column2) match
    case Some(value) => Some(Database(List(value)))
    case None => None
}

implicit def PP_SQL_DB_Join(t: (Option[Database], String, String, String, String, String)): Option[PP_SQL_DB] = {
  if (t._1.isEmpty || t._2 != "JOIN") None
  else Some(JoinTables(t._1.get, t._3, t._4, t._5, t._6))
}

trait PP_SQL_Table{
  def eval: Option[Table]
}

case class InsertRow(table:Table, values: Tabular) extends PP_SQL_Table{
  def eval: Option[Table] = Some(values.foldLeft(table)(_.insert(_)))
}

implicit def PP_SQL_Table_Insert(t: (Option[Table], String, Tabular)): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "INSERT") None
  else Some(InsertRow(t._1.get, t._3))
}

case class UpdateRow(table: Table, condition: FilterCond, updates: Map[String, String]) extends PP_SQL_Table {
  def eval: Option[Table] =
    if (updates.isEmpty) None
    else Some(table.update(condition, updates))
}

implicit def PP_SQL_Table_Update(t: (Option[Table], String, FilterCond, Map[String, String])): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "UPDATE") None
  else Some(UpdateRow(t._1.get, t._3, t._4))
}

case class SortTable(table: Table, column: String) extends PP_SQL_Table{
  def eval: Option[Table] = {
    if (column.nonEmpty) Some(table.sort(column))
    else None
  }
}

implicit def PP_SQL_Table_Sort(t: (Option[Table], String, String)): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "SORT") None
  else Some(SortTable(t._1.get, t._3))
}

case class DeleteRow(table: Table, row: Row) extends PP_SQL_Table{
  def eval: Option[Table] = {
    if (row.nonEmpty) Some(table.delete(row))
    else None
  }
}

implicit def PP_SQL_Table_Delete(t: (Option[Table], String, Row)): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "DELETE") None
  else Some(DeleteRow(t._1.get, t._3))
}

case class FilterRows(table: Table, condition: FilterCond) extends PP_SQL_Table{
  def eval: Option[Table] = Some(table.filter(condition))
}

implicit def PP_SQL_Table_Filter(t: (Option[Table], String, FilterCond)): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "FILTER") None
  else Some(FilterRows(t._1.get, t._3))
}

case class SelectColumns(table: Table, columns: List[String]) extends PP_SQL_Table{
  def eval: Option[Table] = {
    val selected = table.select(columns)
    if (selected.tableData.nonEmpty) Some(selected)
    else None
  }
}

implicit def PP_SQL_Table_Select(t: (Option[Table], String, List[String])): Option[PP_SQL_Table] = {
  if (t._1.isEmpty || t._2 != "EXTRACT") None
  else Some(SelectColumns(t._1.get, t._3))
}

def queryT(p: Option[PP_SQL_Table]): Option[Table] = p match
  case Some(value) => value.eval
  case None => None
def queryDB(p: Option[PP_SQL_DB]): Option[Database] = p match
  case Some(value) => value.eval
  case None => None