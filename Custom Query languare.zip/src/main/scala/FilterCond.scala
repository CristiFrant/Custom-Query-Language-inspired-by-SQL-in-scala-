import scala.language.implicitConversions

trait FilterCond {def eval(r: Row): Option[Boolean]}

case class Field(colName: String, predicate: String => Boolean) extends FilterCond {
  override def eval(r: Row): Option[Boolean] = {
    val entry = r.get(colName)
    if (entry.isEmpty) None
    else Some(predicate(entry.get))
  }
}

case class Compound(op: (Boolean, Boolean) => Boolean, conditions: List[FilterCond]) extends FilterCond {
  override def eval(r: Row): Option[Boolean] = {
    val bools = conditions.map(_.eval(r).getOrElse(false))
    Some(bools.tail.foldLeft(bools.head)(op))
  }
}

case class Not(f: FilterCond) extends FilterCond {
  override def eval(r: Row): Option[Boolean] = {
    val bool = f.eval(r)
    if (bool.isEmpty) None
    else Some(!bool.get)
  }
}

def And(f1: FilterCond, f2: FilterCond): FilterCond = {
  Compound(_ && _, List(f1, f2))
}
def Or(f1: FilterCond, f2: FilterCond): FilterCond = {
  Compound(_ || _, List(f1, f2))
}
def Equal(f1: FilterCond, f2: FilterCond): FilterCond = {
  Compound(_ == _, List(f1, f2))
}

case class Any(fs: List[FilterCond]) extends FilterCond {
  override def eval(r: Row): Option[Boolean] = Compound(_ || _, fs).eval(r)
}

case class All(fs: List[FilterCond]) extends FilterCond {
  override def eval(r: Row): Option[Boolean] = Compound(_ && _, fs).eval(r)
}

implicit def tuple2Field(t: (String, String => Boolean)): Field = {
  Field(t._1, t._2)
}

extension (f: FilterCond) {
  def ===(other: FilterCond) = Equal(f, other)
  def &&(other: FilterCond) = And(f, other)
  def ||(other: FilterCond) = Or(f, other)
  def !! = Not(f)
}