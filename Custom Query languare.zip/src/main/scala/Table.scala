import scala.language.postfixOps

type Row = Map[String, String]
type Tabular = List[Row]

case class Table (tableName: String, tableData: Tabular) {

  override def toString: String = {
    val headers = header.mkString(",")
    // getOrElse used to get rid of Option container
    val rows = data.map(row => header.map(row.getOrElse(_, "")).mkString(","))
    (headers :: rows).mkString("\n")
  }

  def insert(row: Row): Table = {
    if (!tableData.contains(row)) Table(tableName, tableData :+ row)
    else this
  }

  def delete(row: Row): Table = {
    Table(tableName, tableData.filter(_ != row))
  }

  def sort(column: String): Table = {
    val data = tableData.sortBy(_.getOrElse(column, ""))
    Table(tableName, data)
  }

  def update(f: FilterCond, updates: Map[String, String]): Table = {
    val data = tableData.foldLeft(List.empty[Map[String, String]])((acc, row) =>
      if !f.eval(row).get then acc :+ row else acc :+ (row ++ updates))
    Table(tableName, data)
  }

  def filter(f: FilterCond): Table = {
    val data = tableData.foldLeft(List.empty[Map[String, String]])((acc, row) =>
      if f.eval(row).get then acc :+ row else acc)
    Table(tableName, data)
  }

  def select(columns: List[String]): Table = {
    val data = tableData.map(_.filter((key, value) => columns.contains(key)))
    Table(tableName, data)
  }

  def header: List[String] = tableData.head.keys.toList
  def data: Tabular = tableData
  def name: String = tableName
}

object Table {
  def apply(name: String, s: String): Table = {
    val lines = s.split("\n").toList
    val headers = lines.head.split(",")
    val tableData = lines.tail.map { line =>
      val values = line.split(",")
      headers.zip(values).toMap
    }

    Table(name, tableData)
  }
}

extension (table: Table) {
  def apply(i: Int): Row = {
    def aux_apply(idx: Int, data: Tabular): Row = {
      if (idx <= 0) data.head
      else aux_apply(idx - 1, data.tail)
    }

    aux_apply(i, table.tableData)
  } // Implement indexing here, find the right function to override
}
