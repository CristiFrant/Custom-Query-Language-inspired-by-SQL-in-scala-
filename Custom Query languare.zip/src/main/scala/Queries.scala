object Queries {

  def killJackSparrow(t: Table): Option[Table] =
    Some(t.filter(Field("name", _ != "Jack")))

  def insertLinesThenSort(db: Database): Option[Table] =
    Some(db.create("Inserted Fellas").tables.last
      .insert(Map("name" -> "Ana", "age" -> "93", "CNP" -> "455550555"))
      .insert(Map("name" -> "Diana", "age" -> "33", "CNP" -> "255532142"))
      .insert(Map("name" -> "Tatiana", "age" -> "55", "CNP" -> "655532132"))
      .insert(Map("name" -> "Rosmaria", "age" -> "12", "CNP" -> "855532172"))
      .sort("age"))

  def youngAdultHobbiesJ(db: Database): Option[Table] =
    Some(db.join("People", "name", "Hobbies", "name")
      .get.filter(Compound(_ && _, List(Field("age", _.toInt < 25),
        Field("name", _.startsWith("J")), Field("hobby", _.nonEmpty))))
      .select(List("name", "hobby")))
}
